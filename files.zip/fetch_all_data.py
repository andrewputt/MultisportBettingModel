"""
fetch_all_data.py
─────────────────────────────────────────────────────────────────────────────
Triple-stream EPL data ingestion.

  Stream 1 – The Odds API    : Live EPL player props (shots, assists, saves)
  Stream 2 – fbref / Stathead: Team xG, clean-sheet data, form tables
  Stream 3 – Kalshi          : EPL match markets (yes_ask implied prob)

All outputs land in data/raw/epl/:
  epl_odds_props.json
  epl_team_stats.csv
  epl_kalshi.json

Usage
  python fetch_all_data.py
  python fetch_all_data.py --streams odds fbref   # run specific streams
"""

import argparse
import json
import os
import sys
import time
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Optional

import pandas as pd
import requests
from dotenv import load_dotenv

# ── env ───────────────────────────────────────────────────────────────────────
ROOT     = Path(__file__).resolve().parent.parent.parent
ENV_PATH = ROOT / ".env"
load_dotenv(dotenv_path=ENV_PATH)

ODDS_API_KEY  = os.getenv("ODDS_API_KEY", "")
KALSHI_API_KEY = os.getenv("KALSHI_API_KEY", "")

RAW_DIR = ROOT / "data" / "raw" / "epl"
RAW_DIR.mkdir(parents=True, exist_ok=True)

# ── EPL team name normalization ───────────────────────────────────────────────
CANONICAL_TEAM_MAP: dict[str, str] = {
    "Arsenal":                  "ARS",
    "Aston Villa":              "AVL",
    "Bournemouth":              "BOU",
    "Brentford":                "BRE",
    "Brighton and Hove Albion": "BHA",
    "Brighton":                 "BHA",
    "Chelsea":                  "CHE",
    "Crystal Palace":           "CRY",
    "Everton":                  "EVE",
    "Fulham":                   "FUL",
    "Ipswich Town":             "IPS",
    "Leicester City":           "LEI",
    "Liverpool":                "LIV",
    "Manchester City":          "MCI",
    "Manchester United":        "MUN",
    "Newcastle United":         "NEW",
    "Nottingham Forest":        "NFO",
    "Southampton":              "SOU",
    "Tottenham Hotspur":        "TOT",
    "West Ham United":          "WHU",
    "Wolverhampton Wanderers":  "WOL",
    "Wolves":                   "WOL",
    # Odds API variants
    "Brighton & Hove Albion":   "BHA",
    "Nottingham Forest FC":     "NFO",
    "Tottenham":                "TOT",
}

# ── Odds API: EPL player prop markets ────────────────────────────────────────
EPL_PROP_MARKETS = [
    "player_shots",
    "player_shots_on_target",
    "player_assists",
    "player_saves",
]

EPL_SPORT_KEY = "soccer_epl"


def normalize_team(name: str) -> str:
    return CANONICAL_TEAM_MAP.get(name, name[:3].upper())


# ─────────────────────────────────────────────────────────────────────────────
# STREAM 1 — The Odds API: EPL player props
# ─────────────────────────────────────────────────────────────────────────────

def fetch_odds_props() -> list[dict]:
    """
    Pull EPL player props from The Odds API.
    Returns a flat list of prop dicts with implied probabilities.
    """
    if not ODDS_API_KEY:
        print("  [odds] ODDS_API_KEY not set — skipping")
        return []

    base = "https://api.the-odds-api.com/v4"
    today_str = date.today().isoformat()

    # 1. Get today's EPL events
    events_url = f"{base}/sports/{EPL_SPORT_KEY}/events"
    try:
        resp = requests.get(
            events_url,
            params={"apiKey": ODDS_API_KEY, "dateFormat": "iso"},
            timeout=20,
        )
        resp.raise_for_status()
        events = resp.json()
    except Exception as e:
        print(f"  [odds] events fetch failed: {e}")
        return []

    # Filter to today's matches
    today_events = [
        ev for ev in events
        if ev.get("commence_time", "").startswith(today_str)
    ]
    print(f"  [odds] {len(today_events)} EPL events today")

    all_props: list[dict] = []

    for ev in today_events[:12]:  # cap at 12 games (one full matchday)
        event_id   = ev["id"]
        home_team  = normalize_team(ev.get("home_team", ""))
        away_team  = normalize_team(ev.get("away_team", ""))
        commence   = ev.get("commence_time", "")

        for market in EPL_PROP_MARKETS:
            url = f"{base}/sports/{EPL_SPORT_KEY}/events/{event_id}/odds"
            try:
                resp = requests.get(
                    url,
                    params={
                        "apiKey":  ODDS_API_KEY,
                        "markets": market,
                        "regions": "us,uk",
                        "oddsFormat": "american",
                        "dateFormat": "iso",
                    },
                    timeout=20,
                )
                if resp.status_code == 422:
                    # market not available for this event
                    continue
                resp.raise_for_status()
                data = resp.json()
            except Exception as e:
                print(f"  [odds] {market} @ {home_team} failed: {e}")
                continue

            for bookmaker in data.get("bookmakers", []):
                book_name = bookmaker.get("key", "")
                for mkt in bookmaker.get("markets", []):
                    if mkt.get("key") != market:
                        continue
                    for outcome in mkt.get("outcomes", []):
                        # Convert American odds to implied probability
                        price = outcome.get("price", 0)
                        if price > 0:
                            raw_prob = 100 / (price + 100)
                        else:
                            raw_prob = abs(price) / (abs(price) + 100)

                        all_props.append({
                            "player":       outcome.get("description", outcome.get("name", "")),
                            "market":       market,
                            "line":         outcome.get("point", 0.5),
                            "side":         outcome.get("name", "Over"),
                            "raw_prob":     round(raw_prob * 100, 2),
                            "bookmaker":    book_name,
                            "home_team":    home_team,
                            "away_team":    away_team,
                            "commence_time": commence,
                        })

        time.sleep(0.15)  # be polite to the API

    print(f"  [odds] {len(all_props)} raw prop lines fetched")
    out_path = RAW_DIR / "epl_odds_props.json"
    out_path.write_text(json.dumps(all_props, indent=2), encoding="utf-8")
    print(f"  [odds] → {out_path}")
    return all_props


# ─────────────────────────────────────────────────────────────────────────────
# STREAM 2 — fbref: team xG, clean sheets, form
# ─────────────────────────────────────────────────────────────────────────────

# fbref season URLs (2024-25 EPL)
FBREF_SQUAD_STATS_URL = (
    "https://fbref.com/en/comps/9/2024-2025/stats/"
    "2024-2025-Premier-League-Stats"
)
FBREF_KEEPER_URL = (
    "https://fbref.com/en/comps/9/2024-2025/keepers/"
    "2024-2025-Premier-League-Stats"
)

def _safe_float(val) -> float:
    try:
        return float(str(val).replace(",", "").strip())
    except (ValueError, TypeError):
        return 0.0


def fetch_fbref_team_stats() -> pd.DataFrame:
    """
    Pull team-level xG and clean sheet data from fbref.
    Returns a DataFrame with one row per team.
    """
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept-Language": "en-US,en;q=0.9",
    }

    records: list[dict] = []

    # ── Squad shooting stats (xG per 90) ─────────────────────────────────────
    try:
        tables = pd.read_html(
            FBREF_SQUAD_STATS_URL,
            attrs={"id": "stats_squads_standard_for"},
            flavor="lxml",
        )
        df_sq = tables[0]
        # flatten multi-index if present
        if isinstance(df_sq.columns, pd.MultiIndex):
            df_sq.columns = [
                " ".join(filter(None, map(str, c))).strip()
                for c in df_sq.columns
            ]
        # find xG column
        xg_col = next(
            (c for c in df_sq.columns if "xg" in c.lower() and "90" not in c.lower()),
            None,
        )
        team_col = next(
            (c for c in df_sq.columns if "squad" in c.lower()),
            df_sq.columns[0],
        )
        for _, row in df_sq.iterrows():
            team_raw = str(row.get(team_col, "")).strip()
            if not team_raw or team_raw.lower() in ("squad", "nan"):
                continue
            code = normalize_team(team_raw)
            xg   = _safe_float(row.get(xg_col, 0)) if xg_col else 0.0
            records.append({"team": code, "xg_for": xg})
        print(f"  [fbref] squad xG rows: {len(records)}")
    except Exception as e:
        print(f"  [fbref] squad stats failed: {e}")

    # ── Goalkeeper stats (saves, clean sheets) ───────────────────────────────
    cs_map: dict[str, float] = {}
    saves_map: dict[str, float] = {}
    try:
        tables = pd.read_html(
            FBREF_KEEPER_URL,
            attrs={"id": "stats_squads_keeper_for"},
            flavor="lxml",
        )
        df_gk = tables[0]
        if isinstance(df_gk.columns, pd.MultiIndex):
            df_gk.columns = [
                " ".join(filter(None, map(str, c))).strip()
                for c in df_gk.columns
            ]
        cs_col = next(
            (c for c in df_gk.columns if "cs" in c.lower() or "clean" in c.lower()),
            None,
        )
        saves_col = next(
            (c for c in df_gk.columns if "save" in c.lower() and "%" not in c),
            None,
        )
        team_col2 = next(
            (c for c in df_gk.columns if "squad" in c.lower()),
            df_gk.columns[0],
        )
        games_col = next(
            (c for c in df_gk.columns if "90s" in c.lower() or "mp" in c.lower()),
            None,
        )
        for _, row in df_gk.iterrows():
            team_raw = str(row.get(team_col2, "")).strip()
            if not team_raw or team_raw.lower() in ("squad", "nan"):
                continue
            code = normalize_team(team_raw)
            games = max(_safe_float(row.get(games_col, 34)), 1) if games_col else 34
            cs  = _safe_float(row.get(cs_col, 0)) / games if cs_col else 0.0
            sv  = _safe_float(row.get(saves_col, 0)) / games if saves_col else 0.0
            cs_map[code]    = round(cs, 3)
            saves_map[code] = round(sv, 3)
        print(f"  [fbref] GK clean-sheet rows: {len(cs_map)}")
    except Exception as e:
        print(f"  [fbref] keeper stats failed: {e}")

    # Merge
    df = pd.DataFrame(records) if records else pd.DataFrame(columns=["team", "xg_for"])
    df["cs_rate"]    = df["team"].map(cs_map).fillna(0.28)
    df["saves_pg"]   = df["team"].map(saves_map).fillna(3.2)

    out_path = RAW_DIR / "epl_team_stats.csv"
    df.to_csv(out_path, index=False)
    print(f"  [fbref] → {out_path}")
    return df


# ─────────────────────────────────────────────────────────────────────────────
# STREAM 3 — Kalshi: EPL match markets
# ─────────────────────────────────────────────────────────────────────────────

def fetch_kalshi() -> list[dict]:
    """Pull EPL markets from Kalshi (KXEPL* series)."""
    if not KALSHI_API_KEY:
        print("  [kalshi] KALSHI_API_KEY not set — skipping")
        return []

    url = "https://trading-api.kalshi.com/trade-api/v2/markets"
    params = {
        "event_ticker_series": "KXEPL",
        "status": "open",
        "limit": 200,
    }
    headers = {
        "Authorization": f"Bearer {KALSHI_API_KEY}",
        "Content-Type": "application/json",
    }
    try:
        resp = requests.get(url, params=params, headers=headers, timeout=20)
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        print(f"  [kalshi] fetch failed: {e}")
        return []

    markets = data.get("markets", [])
    out = []
    for m in markets:
        yes_ask = m.get("yes_ask", 0) or 0
        out.append({
            "ticker":      m.get("ticker", ""),
            "title":       m.get("title", ""),
            "yes_ask":     yes_ask,
            "implied_prob": round(yes_ask / 100, 4),
            "close_time":  m.get("close_time", ""),
        })

    out_path = RAW_DIR / "epl_kalshi.json"
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(f"  [kalshi] {len(out)} EPL markets → {out_path}")
    return out


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

STREAM_MAP = {
    "odds":  fetch_odds_props,
    "fbref": fetch_fbref_team_stats,
    "kalshi": fetch_kalshi,
}


def main() -> None:
    parser = argparse.ArgumentParser(description="EPL data ingestion")
    parser.add_argument(
        "--streams",
        nargs="+",
        choices=list(STREAM_MAP.keys()),
        default=list(STREAM_MAP.keys()),
        help="Which streams to run (default: all)",
    )
    args = parser.parse_args()

    print(f"\n[EPL fetch_all_data] {date.today()} — streams: {args.streams}")
    for stream in args.streams:
        print(f"\n── {stream} ──")
        STREAM_MAP[stream]()
    print("\n[EPL fetch_all_data] Done.")


if __name__ == "__main__":
    main()
