#!/usr/bin/env python3
"""
generate_dashboard.py
─────────────────────────────────────────────────────────────────────────────
Reads epl_golden.csv + epl_summary.json from data/processed/epl/ and
writes a self-contained HTML dashboard with today's real EPL data embedded.

Run after process_model.py:
  python3 src/EPL/generate_dashboard.py

The dashboard is written to:
  data/processed/epl/epl_dashboard.html   ← open directly in any browser

Mirrors the MLB generate_dashboard.py pattern exactly so the same
dashboard_template.html works for both pipelines.
"""

import csv
import json
import re
import sys
from datetime import date
from pathlib import Path


ROOT          = Path(__file__).resolve().parent.parent.parent
PROCESSED_DIR = ROOT / "data" / "processed" / "epl"
GOLDEN_CSV    = PROCESSED_DIR / "epl_golden.csv"
SUMMARY_JSON  = PROCESSED_DIR / "epl_summary.json"

_template_candidates = [
    ROOT / "dashboard_template.html",
    Path(__file__).resolve().parent / "dashboard_template.html",
]
TEMPLATE_HTML = next((p for p in _template_candidates if p.exists()), _template_candidates[0])
OUTPUT_HTML   = PROCESSED_DIR / "epl_dashboard.html"

PICKS_JSON = PROCESSED_DIR / "epl_picks_history.json"

# ── market label → display name ──────────────────────────────────────────────
MARKET_LABELS = {
    "player_shots":            "Shots",
    "player_shots_on_target":  "Shots on Tgt",
    "player_assists":          "Assists",
    "player_saves":            "Saves",
    # already-mapped labels (process_model.py pre-maps these)
    "Shots":        "Shots",
    "Shots on Tgt": "Shots on Tgt",
    "Assists":      "Assists",
    "Saves":        "Saves",
}


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS (mirrors MLB generate_dashboard.py)
# ─────────────────────────────────────────────────────────────────────────────

def _get(row: dict, *keys, default=""):
    for k in keys:
        if k in row and row[k] not in ("", None):
            return row[k]
    return default


def _pct(val: str) -> float:
    """Parse '58.3%' or '0.583' or '58.3' → float percentage (0–100)."""
    if not val:
        return 0.0
    s = str(val).strip().rstrip("%")
    try:
        f = float(s)
        return round(f * 100, 1) if f <= 1.0 else round(f, 1)
    except ValueError:
        return 0.0


# ─────────────────────────────────────────────────────────────────────────────
# LOAD
# ─────────────────────────────────────────────────────────────────────────────

def load_golden(path: Path) -> list[dict]:
    """
    Load ALL rows from epl_golden.csv.
    Returns a list of dicts shaped for the dashboard's EPL_EDGES array.

    Required fields per EPL row (from dashboard_template.html TODO block):
      id, player, team, opp, gameTime, market, line, side,
      book, model,
      xgForm:    number|null  (expected goals form, e.g. 0.72)
      cleanSheet: number|null (clean sheet probability 0-1)
    """
    if not path.exists():
        return []

    rows: list[dict] = []
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        cols   = set(reader.fieldnames or [])
        print(f"  [generate_dashboard] epl_golden.csv columns: {sorted(cols)}")

        for i, row in enumerate(reader):
            raw_market = _get(row, "market_raw", "market")
            mkt_prob   = _pct(_get(row, "mkt_prob",   "market_prob", "book_prob"))
            model_prob = _pct(_get(row, "model_prob",  "predicted_prob"))
            edge_raw   = _get(row, "edge", "edge_pct", "ev")
            edge_val   = _pct(edge_raw) if edge_raw else round(model_prob - mkt_prob, 1)

            xg_home    = float(_get(row, "xg_home", "xg_for") or 1.45)
            xg_away    = float(_get(row, "xg_away") or 1.45)
            xg_form    = round((xg_home + xg_away) / 2, 2)

            cs_raw     = _get(row, "clean_sheet_prob", "cs_rate")
            cs_prob    = float(cs_raw) if cs_raw else None

            rows.append({
                "rank":        i + 1,
                "player":      _get(row, "player", "player_name", "name"),
                "market":      MARKET_LABELS.get(raw_market, raw_market),
                "marketRaw":   raw_market,
                "line":        _get(row, "line", "line_value", "prop_line"),
                "side":        _get(row, "side", default="Over"),
                "mktProb":     mkt_prob,
                "modelProb":   model_prob,
                "edge":        edge_val,
                # Dashboard fields
                "book":        mkt_prob,
                "model":       model_prob,
                "homeTeam":    _get(row, "home_team", "home"),
                "awayTeam":    _get(row, "away_team", "away"),
                "team":        _get(row, "home_team", "home"),
                "opp":         _get(row, "away_team", "away"),
                "commence":    _get(row, "commence_time", "game_time", "start_time"),
                # EPL-specific
                "xgForm":      xg_form,
                "cleanSheet":  cs_prob,
                "bookmaker":   _get(row, "bookmaker", "book"),
            })

    return rows


def load_summary(path: Path) -> dict:
    if not path.exists():
        return {}
    with open(path, encoding="utf-8") as f:
        return json.load(f)


# ─────────────────────────────────────────────────────────────────────────────
# META
# ─────────────────────────────────────────────────────────────────────────────

def build_meta(rows: list[dict], summary: dict, run_date: str) -> dict:
    """
    Build INJECTED_META consumed by dashboard_template.html.
    Mirrors the MLB meta structure exactly.
    """
    plays_n    = sum(1 for r in rows if (r["modelProb"] - r["mktProb"]) >= 8.0)
    edges      = [r["modelProb"] - r["mktProb"] for r in rows if r["modelProb"] - r["mktProb"] > 0]
    avg_edge   = round(sum(edges) / len(edges), 1) if edges else 0.0
    scanned    = summary.get("total_props", len(rows))
    signal     = min(95, max(40, int(avg_edge * 10)))

    return {
        "date":           run_date,
        "scanned":        scanned,
        "plays":          plays_n,
        "avgEdge":        avg_edge,
        "signalStrength": signal,
        "regime_2025":    75,
        "regime_2026":    25,
        "pivotDate":      "May 15 2026",
        "threshold":      8.0,
        "ingestion": [
            {"name": "Odds API",        "status": "live",   "latency": 110},
            {"name": "Kalshi Markets",  "status": "live",   "latency": 64},
            {"name": "fbref / Opta",    "status": "live",   "latency": 0},
            {"name": "FBRef Stats",     "status": "cached", "latency": 3600},
        ],
    }


# ─────────────────────────────────────────────────────────────────────────────
# PICKS TRACKER (mirrors MLB)
# ─────────────────────────────────────────────────────────────────────────────

def save_picks(rows: list[dict], run_date: str) -> None:
    """Append today's top-5 EPL picks to epl_picks_history.json."""
    top5  = sorted(rows, key=lambda r: r["edge"], reverse=True)[:5]
    picks = [
        {
            "rank":      i + 1,
            "player":    r["player"],
            "market":    r["market"],
            "marketRaw": r["marketRaw"],
            "line":      r["line"],
            "side":      r.get("side", "Over"),
            "mktProb":   r["mktProb"],
            "modelProb": r["modelProb"],
            "edge":      r["edge"],
            "result":    None,
        }
        for i, r in enumerate(top5)
    ]

    history: dict = {}
    if PICKS_JSON.exists():
        try:
            with open(PICKS_JSON, encoding="utf-8") as f:
                history = json.load(f)
        except json.JSONDecodeError:
            history = {}

    if run_date in history:
        existing = {p["rank"]: p for p in history[run_date].get("picks", [])}
        for p in picks:
            if p["rank"] in existing and existing[p["rank"]].get("result") is not None:
                p["result"] = existing[p["rank"]]["result"]

    history[run_date] = {"picks": picks}
    PICKS_JSON.write_text(json.dumps(history, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"  [picks_history] Top 5 EPL picks saved → {PICKS_JSON}")
    print(
        f"    Record results: "
        f"python3 src/EPL/generate_dashboard.py --record {run_date} WIN LOSS WIN WIN LOSS"
    )


def record_results(target_date: str, results: list[str]) -> None:
    if not PICKS_JSON.exists():
        print(f"[record_results] No epl_picks_history.json at {PICKS_JSON}")
        return

    with open(PICKS_JSON, encoding="utf-8") as f:
        history = json.load(f)

    if target_date not in history:
        print(f"[record_results] No picks found for {target_date}")
        print(f"  Available: {', '.join(sorted(history.keys()))}")
        return

    picks = history[target_date]["picks"]
    valid = {"WIN", "LOSS", "PUSH", "N/A"}
    for i, pick in enumerate(picks):
        if i < len(results):
            r = results[i].upper()
            if r not in valid:
                print(f"  [warn] #{i+1} result '{r}' not in {valid}, skipping")
                continue
            pick["result"] = r
            print(f"  #{i+1} {pick['player']} {pick['market']} → {r}")

    recorded = [p["result"] for p in picks if p["result"] in {"WIN", "LOSS", "PUSH"}]
    if recorded:
        wins   = recorded.count("WIN")
        losses = recorded.count("LOSS")
        pushes = recorded.count("PUSH")
        history[target_date]["record"] = (
            f"{wins}-{losses}" + (f"-{pushes}" if pushes else "")
        )

    PICKS_JSON.write_text(json.dumps(history, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"  Saved → {PICKS_JSON}")


# ─────────────────────────────────────────────────────────────────────────────
# TEMPLATE INJECTION
# ─────────────────────────────────────────────────────────────────────────────

def inject_epl(template: str, rows: list[dict], meta: dict) -> str:
    """
    Replace the EPL_EDGES = [] placeholder and the INJECT_META markers.

    The template has:
      const EPL_EDGES = [];                        ← replace with real rows
      /*INJECT_META_START*/ ... /*INJECT_META_END*/ ← replace meta (MLB meta;
                                                       EPL uses its own meta
                                                       block below)

    We add an EPL-specific meta block right after EPL_EDGES injection
    so the dashboard can read EPL signal separately if desired.
    """
    rows_json = json.dumps(rows, indent=2)
    meta_json = json.dumps(meta, indent=2)

    # Replace the empty EPL_EDGES array
    out = re.sub(
        r"(//\s*──\s*EPL:.*?const EPL_EDGES\s*=\s*)\[\];",
        lambda m: m.group(1) + rows_json + ";",
        template,
        flags=re.DOTALL,
    )

    # Also inject the meta (replaces existing INJECT markers for MLB — we keep
    # MLB markers intact and inject EPL meta into a separate variable block)
    epl_meta_block = f"\n      const EPL_META = {meta_json};\n"
    out = out.replace(
        "// ── EPL: replace this empty array with your pipeline output ──────",
        "// ── EPL: generated by generate_dashboard.py ──────────────────────"
        + epl_meta_block
        + "      // ── EPL data (generated) ──────────────────────────────────────",
    )

    return out


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def main() -> None:
    if "--record" in sys.argv:
        idx      = sys.argv.index("--record")
        target   = sys.argv[idx + 1] if idx + 1 < len(sys.argv) else None
        outcomes = sys.argv[idx + 2:idx + 7]
        if not target:
            sys.exit("Usage: generate_dashboard.py --record <YYYY-MM-DD> WIN|LOSS|PUSH ...")
        record_results(target, outcomes)
        return

    if not GOLDEN_CSV.exists():
        sys.exit(
            f"[EPL generate_dashboard] ERROR: {GOLDEN_CSV} not found.\n"
            "Run src/EPL/process_model.py first."
        )

    rows     = load_golden(GOLDEN_CSV)
    summary  = load_summary(SUMMARY_JSON)
    run_date = date.today().isoformat()

    save_picks(rows, run_date)

    if not TEMPLATE_HTML.exists():
        print(
            f"[EPL generate_dashboard] WARNING: template not found at {TEMPLATE_HTML}.\n"
            "  Picks saved. Copy dashboard_template.html to the project root."
        )
        return

    meta = build_meta(rows, summary, run_date)

    with open(TEMPLATE_HTML, encoding="utf-8") as f:
        template = f.read()

    html = inject_epl(template, rows, meta)
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_HTML.write_text(html, encoding="utf-8")

    plays = meta["plays"]
    by_market: dict[str, int] = {}
    for r in rows:
        by_market[r["marketRaw"]] = by_market.get(r["marketRaw"], 0) + 1
    market_str = "  ".join(f"{k}={v}" for k, v in sorted(by_market.items()))
    print(
        f"[EPL generate_dashboard] {len(rows)} rows  |  {plays} play(s) ≥8% EV  |  "
        f"avg edge {meta['avgEdge']}%\n"
        f"  Markets: {market_str}\n"
        f"  → {OUTPUT_HTML}"
    )


if __name__ == "__main__":
    main()
