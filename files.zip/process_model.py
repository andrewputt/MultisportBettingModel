"""
process_model.py
─────────────────────────────────────────────────────────────────────────────
Normalization, feature engineering, and edge filtering for the EPL prop model.

Pipeline
  1. Load raw data from data/raw/epl/
        epl_odds_props.json   → American odds → vig-free implied prob
        epl_team_stats.csv    → team xG, clean-sheet rate, saves per game
        epl_kalshi.json       → Kalshi yes_ask → implied prob (signal blend)

  2. Standardize team names via CANONICAL_TEAM_MAP

  3. Feature Engineering
        • Odds API: explicit positive/negative American formula → vig-free prob
        • xG factor: team xG rank adjusts shot/assist model probabilities
        • Clean-sheet prior: league clean-sheet rate adjusted by opponent xG rank
        • Saves model: GK saves baseline scaled by opponent attacking form
        • Market vig removal: strip bookmaker margin before comparison
        • Kalshi signal blend: ±2.5% weight where Kalshi market exists

  4. Compute final model edge  (model_prob − market_prob)

  5. Output
        data/processed/epl/epl_golden.csv        – one row per player-prop
        data/processed/epl/epl_summary.json      – aggregate stats

Usage
  python process_model.py
  python process_model.py --date 2026-05-04
"""

import argparse
import json
import math
import os
import warnings
from datetime import date
from pathlib import Path

import numpy as np
import pandas as pd
from dotenv import load_dotenv

warnings.filterwarnings("ignore", category=FutureWarning)

# ── env ───────────────────────────────────────────────────────────────────────
ROOT     = Path(__file__).resolve().parent.parent.parent
ENV_PATH = ROOT / ".env"
load_dotenv(dotenv_path=ENV_PATH)

# ── paths ─────────────────────────────────────────────────────────────────────
RAW_DIR       = ROOT / "data" / "raw" / "epl"
PROCESSED_DIR = ROOT / "data" / "processed" / "epl"
PROCESSED_DIR.mkdir(parents=True, exist_ok=True)

# ─────────────────────────────────────────────────────────────────────────────
# TEAM NAME NORMALIZATION
# ─────────────────────────────────────────────────────────────────────────────
CANONICAL_TEAM_MAP: dict[str, str] = {
    "Arsenal":                  "ARS",
    "Aston Villa":              "AVL",
    "Bournemouth":              "BOU",
    "Brentford":                "BRE",
    "Brighton and Hove Albion": "BHA",
    "Brighton":                 "BHA",
    "Brighton & Hove Albion":   "BHA",
    "Chelsea":                  "CHE",
    "Crystal Palace":           "CRY",
    "Everton":                  "EVE",
    "Fulham":                   "FUL",
    "Ipswich Town":             "IPS",
    "Ipswich":                  "IPS",
    "Leicester City":           "LEI",
    "Leicester":                "LEI",
    "Liverpool":                "LIV",
    "Manchester City":          "MCI",
    "Man City":                 "MCI",
    "Manchester United":        "MUN",
    "Man United":               "MUN",
    "Man Utd":                  "MUN",
    "Newcastle United":         "NEW",
    "Newcastle":                "NEW",
    "Nottingham Forest":        "NFO",
    "Nottingham Forest FC":     "NFO",
    "Southampton":              "SOU",
    "Tottenham Hotspur":        "TOT",
    "Tottenham":                "TOT",
    "West Ham United":          "WHU",
    "West Ham":                 "WHU",
    "Wolverhampton Wanderers":  "WOL",
    "Wolves":                   "WOL",
}


def normalize_team(name: str) -> str:
    return CANONICAL_TEAM_MAP.get(name, name[:3].upper() if len(name) >= 3 else name)


# ─────────────────────────────────────────────────────────────────────────────
# MARKET CONFIG
# ─────────────────────────────────────────────────────────────────────────────

MARKET_LABEL_MAP = {
    "player_shots":            "Shots",
    "player_shots_on_target":  "Shots on Tgt",
    "player_assists":          "Assists",
    "player_saves":            "Saves",
}

# League-wide baseline props per 90 (2024-25 EPL averages)
# Used when fbref data is unavailable for a team
LEAGUE_BASELINES = {
    "player_shots":           3.1,   # average shots for an attacker per 90
    "player_shots_on_target": 1.1,
    "player_assists":         0.22,
    "player_saves":           3.4,   # GK saves per 90
}

# xG rank → attacking multiplier (1 = league average)
# Higher xG rank = stronger attack = more shots/assists expected
def xg_multiplier(xg_for: float, league_avg_xg: float = 1.45) -> float:
    """Scale model prob by team's xG relative to league average."""
    if league_avg_xg <= 0:
        return 1.0
    ratio = xg_for / league_avg_xg
    # Cap between 0.80 and 1.20 to avoid extreme swings
    return round(min(max(ratio, 0.80), 1.20), 4)


# ─────────────────────────────────────────────────────────────────────────────
# PROBABILITY HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def american_to_prob(odds: float) -> float:
    """Convert American moneyline odds to implied probability (0–1)."""
    if odds >= 0:
        return 100 / (odds + 100)
    return abs(odds) / (abs(odds) + 100)


def remove_vig(over_prob: float, under_prob: float) -> tuple[float, float]:
    """Remove bookmaker vig to get fair no-vig probabilities."""
    total = over_prob + under_prob
    if total <= 0:
        return over_prob, under_prob
    return over_prob / total, under_prob / total


def line_prob(line: float, baseline: float, sd_factor: float = 0.9) -> float:
    """
    Model probability of the OVER for a given stat line.
    Uses a simple normal CDF approximation around the baseline.
    baseline  = expected value for the player (stat per 90 × minutes weight)
    sd_factor = assumed standard deviation as a fraction of the baseline
    """
    if baseline <= 0:
        return 0.5
    sd   = max(baseline * sd_factor, 0.3)
    # P(X > line) where X ~ N(baseline, sd)
    z    = (line - baseline) / sd
    # Approximation to the standard normal CDF
    prob = 0.5 * math.erfc(z / math.sqrt(2))
    return round(min(max(prob, 0.05), 0.95), 4)


# ─────────────────────────────────────────────────────────────────────────────
# LOAD RAW DATA
# ─────────────────────────────────────────────────────────────────────────────

def load_odds_props() -> pd.DataFrame:
    path = RAW_DIR / "epl_odds_props.json"
    if not path.exists():
        print(f"  [process] WARNING: {path} not found — using empty DataFrame")
        return pd.DataFrame()
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if not data:
        return pd.DataFrame()
    return pd.DataFrame(data)


def load_team_stats() -> pd.DataFrame:
    path = RAW_DIR / "epl_team_stats.csv"
    if not path.exists():
        print(f"  [process] WARNING: {path} not found — using league defaults")
        return pd.DataFrame(columns=["team", "xg_for", "cs_rate", "saves_pg"])
    return pd.read_csv(path)


def load_kalshi() -> dict[str, float]:
    """Return {ticker_suffix: implied_prob} for Kalshi EPL markets."""
    path = RAW_DIR / "epl_kalshi.json"
    if not path.exists():
        return {}
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    return {m["ticker"]: m["implied_prob"] for m in data}


# ─────────────────────────────────────────────────────────────────────────────
# FEATURE ENGINEERING
# ─────────────────────────────────────────────────────────────────────────────

def build_team_lookup(df_stats: pd.DataFrame) -> dict[str, dict]:
    """Build {team_code: {xg_for, cs_rate, saves_pg}} for fast lookup."""
    lookup: dict[str, dict] = {}
    if df_stats.empty:
        return lookup
    for _, row in df_stats.iterrows():
        team = str(row.get("team", "")).strip()
        if not team:
            continue
        lookup[team] = {
            "xg_for":   float(row.get("xg_for", 1.45)),
            "cs_rate":  float(row.get("cs_rate", 0.28)),
            "saves_pg": float(row.get("saves_pg", 3.4)),
        }
    return lookup


def derive_team_from_player(
    player: str,
    home_team: str,
    away_team: str,
    market: str,
) -> str:
    """
    Best-effort: assign player to home or away team.
    For saves we assume the player is a GK — use the team with better saves_pg.
    For outfield props we default to home_team (slight home-field bias).
    In production this would come from a player→team roster lookup.
    """
    if market == "player_saves":
        return home_team  # will be overridden by saves_pg logic
    return home_team


def compute_model_prob(
    market: str,
    line: float,
    side: str,
    home_team: str,
    away_team: str,
    team_lookup: dict[str, dict],
) -> float:
    """
    Compute model probability for a given prop line using xG-adjusted baselines.
    """
    home_stats = team_lookup.get(home_team, {})
    away_stats = team_lookup.get(away_team, {})

    league_avg_xg = 1.45  # EPL 2024-25 average

    home_xg  = home_stats.get("xg_for", league_avg_xg)
    away_xg  = away_stats.get("xg_for", league_avg_xg)
    home_cs  = home_stats.get("cs_rate", 0.28)
    away_cs  = away_stats.get("cs_rate", 0.28)
    home_sv  = home_stats.get("saves_pg", 3.4)
    away_sv  = away_stats.get("saves_pg", 3.4)

    # Blended attacking xG (home team attacks against away defense)
    blended_off_xg = (home_xg * 0.6 + away_xg * 0.4)

    if market == "player_shots":
        baseline   = LEAGUE_BASELINES["player_shots"] * xg_multiplier(blended_off_xg, league_avg_xg)
        model_prob = line_prob(line, baseline, sd_factor=0.95)

    elif market == "player_shots_on_target":
        baseline   = LEAGUE_BASELINES["player_shots_on_target"] * xg_multiplier(blended_off_xg, league_avg_xg)
        model_prob = line_prob(line, baseline, sd_factor=1.0)

    elif market == "player_assists":
        baseline   = LEAGUE_BASELINES["player_assists"] * xg_multiplier(blended_off_xg, league_avg_xg)
        model_prob = line_prob(line, baseline, sd_factor=1.2)

    elif market == "player_saves":
        # GK saves correlate with opponent attack: use away team xG as opposing attack
        opp_xg     = away_xg
        opp_mult   = xg_multiplier(opp_xg, league_avg_xg)
        baseline   = home_sv * opp_mult
        model_prob = line_prob(line, baseline, sd_factor=0.85)

    else:
        model_prob = 0.5

    # Clean-sheet adjustment for low-line shots/assists
    if market in ("player_shots", "player_shots_on_target") and line <= 0.5:
        # If the away team is strong defensively, shade down slightly
        cs_adj = (home_cs + away_cs) / 2
        model_prob = model_prob * (1 - cs_adj * 0.10)

    # Flip for UNDER
    if isinstance(side, str) and side.lower() in ("under", "no"):
        model_prob = 1.0 - model_prob

    return round(min(max(model_prob, 0.05), 0.95) * 100, 2)


# ─────────────────────────────────────────────────────────────────────────────
# VIG REMOVAL
# ─────────────────────────────────────────────────────────────────────────────

def remove_vig_from_df(df: pd.DataFrame) -> pd.DataFrame:
    """
    For each (player, market, line, game, bookmaker) group, find the OVER and
    UNDER lines and strip the vig.  Returns df with a new column `no_vig_prob`.
    """
    df = df.copy()
    df["side_lower"] = df["side"].str.lower()
    df["no_vig_prob"] = df["raw_prob"]  # fallback

    # Group by bookmaker + game + player + market + line
    group_keys = ["bookmaker", "home_team", "away_team", "player", "market", "line"]
    for _, grp in df.groupby(group_keys, dropna=False):
        over_rows  = grp[grp["side_lower"].str.contains("over|yes", na=False)]
        under_rows = grp[grp["side_lower"].str.contains("under|no",  na=False)]
        if over_rows.empty or under_rows.empty:
            continue
        o_prob = over_rows["raw_prob"].mean() / 100
        u_prob = under_rows["raw_prob"].mean() / 100
        nv_o, nv_u = remove_vig(o_prob, u_prob)
        df.loc[over_rows.index,  "no_vig_prob"] = round(nv_o * 100, 2)
        df.loc[under_rows.index, "no_vig_prob"] = round(nv_u * 100, 2)

    return df


# ─────────────────────────────────────────────────────────────────────────────
# MAIN PIPELINE
# ─────────────────────────────────────────────────────────────────────────────

def main(run_date: Optional[str] = None) -> None:
    run_date = run_date or date.today().isoformat()
    print(f"\n[EPL process_model] {run_date}")

    # 1. Load
    df_props = load_odds_props()
    df_stats = load_team_stats()
    kalshi   = load_kalshi()
    team_lut = build_team_lookup(df_stats)

    if df_props.empty:
        print(
            "[EPL process_model] No prop data found.\n"
            "  Run fetch_all_data.py first."
        )
        _write_empty_outputs(run_date)
        return

    # 2. Vig removal
    print(f"  Loaded {len(df_props)} raw prop lines")
    df = remove_vig_from_df(df_props)

    # 3. Keep OVER lines only (the side we're modelling)
    df = df[df["side"].str.lower().str.contains("over|yes", na=False)].copy()
    print(f"  {len(df)} OVER lines after vig removal")

    # 4. Aggregate across bookmakers: take the best (highest) no-vig prob line
    agg_cols = ["player", "market", "line", "home_team", "away_team", "commence_time"]
    df_agg = (
        df.groupby(agg_cols, dropna=False)
        .agg(
            mkt_prob   = ("no_vig_prob", "mean"),
            best_book  = ("bookmaker",   lambda x: x.mode().iloc[0] if len(x) else ""),
        )
        .reset_index()
    )

    # 5. Compute model probability for each row
    league_avg_xg = (
        df_stats["xg_for"].mean() if not df_stats.empty and "xg_for" in df_stats.columns else 1.45
    )

    model_probs: list[float] = []
    xg_home_list: list[float] = []
    xg_away_list: list[float] = []
    cs_list:  list[float] = []

    for _, row in df_agg.iterrows():
        home = str(row["home_team"])
        away = str(row["away_team"])

        mp = compute_model_prob(
            market     = str(row["market"]),
            line       = float(row["line"]),
            side       = "over",
            home_team  = home,
            away_team  = away,
            team_lookup = team_lut,
        )
        model_probs.append(mp)

        h_stats = team_lut.get(home, {})
        a_stats = team_lut.get(away, {})
        xg_home_list.append(h_stats.get("xg_for", league_avg_xg))
        xg_away_list.append(a_stats.get("xg_for", league_avg_xg))
        cs_list.append((h_stats.get("cs_rate", 0.28) + a_stats.get("cs_rate", 0.28)) / 2)

    df_agg["model_prob"] = model_probs
    df_agg["xg_home"]    = xg_home_list
    df_agg["xg_away"]    = xg_away_list
    df_agg["cs_rate"]    = cs_list

    # 6. Kalshi signal blend (±2.5% where Kalshi market exists)
    def kalshi_blend(mkt_prob: float, player: str, market: str) -> float:
        key = f"KXEPL-{player[:6].upper().replace(' ', '')}"
        if key in kalshi:
            kal_prob = kalshi[key] * 100
            return round(mkt_prob * 0.975 + kal_prob * 0.025, 2)
        return mkt_prob

    df_agg["mkt_prob"] = df_agg.apply(
        lambda r: kalshi_blend(r["mkt_prob"], r["player"], r["market"]), axis=1
    )

    # 7. Compute edge
    df_agg["edge"] = (df_agg["model_prob"] - df_agg["mkt_prob"]).round(2)

    # 8. Market label
    df_agg["market_label"] = df_agg["market"].map(MARKET_LABEL_MAP).fillna(df_agg["market"])

    # 9. Sort by edge descending, rename for dashboard compatibility
    df_out = df_agg.sort_values("edge", ascending=False).reset_index(drop=True)
    df_out = df_out.rename(columns={
        "player":        "player",
        "market_label":  "market",
        "market":        "market_raw",
        "line":          "line",
        "mkt_prob":      "mkt_prob",
        "model_prob":    "model_prob",
        "edge":          "edge",
        "home_team":     "home_team",
        "away_team":     "away_team",
        "commence_time": "commence_time",
        "best_book":     "bookmaker",
        "xg_home":       "xg_home",
        "xg_away":       "xg_away",
        "cs_rate":       "cs_rate",
    })

    # 10. Clean-sheet probability per row (home GK clean-sheet rate)
    df_out["clean_sheet_prob"] = df_out["home_team"].map(
        {t: s.get("cs_rate", 0.28) for t, s in team_lut.items()}
    ).fillna(0.28)

    # 11. Write golden CSV
    golden_path = PROCESSED_DIR / "epl_golden.csv"
    df_out.to_csv(golden_path, index=False)
    print(f"  [process] → {golden_path}  ({len(df_out)} rows)")

    # 12. Summary JSON
    plays_n  = int((df_out["edge"] >= 8.0).sum())
    avg_edge = round(df_out["edge"].mean(), 2) if not df_out.empty else 0.0
    summary  = {
        "date":         run_date,
        "total_props":  len(df_out),
        "plays_gte8":   plays_n,
        "avg_edge":     avg_edge,
        "markets": df_out["market"].value_counts().to_dict(),
        "top_10": df_out.head(10)[
            ["player", "market", "line", "mkt_prob", "model_prob", "edge",
             "home_team", "away_team"]
        ].to_dict(orient="records"),
    }
    summary_path = PROCESSED_DIR / "epl_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(f"  [process] → {summary_path}")

    print(
        f"\n[EPL process_model] {len(df_out)} props  |  "
        f"{plays_n} play(s) ≥8% edge  |  avg edge {avg_edge}%"
    )

    # Terminal top-5
    top5 = df_out.head(5)
    print("\n  ── Top 5 EPL plays ───────────────────────────────────")
    for _, r in top5.iterrows():
        print(
            f"  {r['player']:25s}  {r['market']:15s}  "
            f"O {r['line']}  "
            f"book={r['mkt_prob']:.1f}%  model={r['model_prob']:.1f}%  "
            f"edge={r['edge']:.1f}%"
        )


def _write_empty_outputs(run_date: str) -> None:
    empty_csv = PROCESSED_DIR / "epl_golden.csv"
    pd.DataFrame(columns=[
        "player", "market", "market_raw", "line", "mkt_prob", "model_prob",
        "edge", "home_team", "away_team", "commence_time", "bookmaker",
        "xg_home", "xg_away", "cs_rate", "clean_sheet_prob",
    ]).to_csv(empty_csv, index=False)

    empty_summary = {
        "date": run_date, "total_props": 0, "plays_gte8": 0,
        "avg_edge": 0.0, "markets": {}, "top_10": [],
    }
    (PROCESSED_DIR / "epl_summary.json").write_text(
        json.dumps(empty_summary, indent=2), encoding="utf-8"
    )


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", default=None)
    args = parser.parse_args()

    from typing import Optional
    main(args.date)
